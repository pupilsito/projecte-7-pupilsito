# Solució: T05: Vídeo formatiu LOPD empleats.

## Tienen la actividad: [T05: Vídeo formatiu LOPD empleats: Jhon Justiniano-Hugo Muiños](https://docs.google.com/document/d/1RBB-XFElGaGn-cxyffKcd174mfz74nFWx_xEnFWaw7w/edit?usp=sharing) por si se les hes más comodo.

# Tasca 1: El Guió i la Recerca

Abans de gravar, cada grup ha de realitzar una recerca complementària a la web de l'AEPD (Agència Espanyola de Protecció de Dades) per assegurar-se que les mesures proposades compleixen amb la LOPD-GDD 3/2018. Heu de redactar un guió detallat per a cada vídeo.

## Guión vídeo 1: Cumplimiento legal en el día a día en Foodlogistic (general)

**Público:** Personal de almacén, transporte y oficinas.

### 1.-Introducción y Conceptos Básicos

**Visual:** Bienvenida con el logo de la empresa y el título del vídeo. Definición de "Dato Personal".

**Locución:** Bienvenidos a esta sesión de formación sobre protección de datos. En FoodLogistic, la seguridad de la información es responsabilidad de todos. Un dato personal es cualquier información que permita identificar a una persona física, como un nombre, un DNI, una matrícula o incluso una dirección de correo electrónico. La ley nos obliga a proteger estos datos para garantizar la privacidad y los derechos fundamentales de clientes y empleados.

### 2.-Uso de Dispositivos y Seguridad Digital

**Visual:** Demostración del atajo de teclado Windows+L y ejemplos de contraseñas robustas.

**Locución:** Nuestro ordenador es la puerta de entrada a mucha información sensible. Para evitar accesos no autorizados, es obligatorio bloquear la sesión cada vez que te alejes del puesto de trabajo pulsando Windows + L. Asimismo, se deben utilizar contraseñas robustas (combinando letras, números y símbolos), que son personales y nunca se deben compartir ni anotar en lugares visibles.

### 3.-Impresión Segura y Gestión de Documentos

**Visual:** Imagen de una bandeja de impresora llena con una cruz roja y una imagen de recogida inmediata con un "check" verde.

**Locución:** Uno de los puntos donde se pierden más datos es en la impresora. Cuando envíes un documento a imprimir que contenga datos personales, recógelo inmediatamente. Dejar documentos en la bandeja expone la información a cualquier persona. Si el documento es confidencial, guárdalo bajo llave cuando no lo utilices.

### 4.-Unidades de Red vs. Almacenamiento Personal

**Visual:** Esquema del servidor de la empresa (correcto) vs. escritorio local o Dropbox personal (incorrecto).

**Locución:** Todo el trabajo debe guardarse en las unidades de red corporativas. Está prohibido guardar archivos con datos personales en el escritorio local o en servicios de nube personales. El uso de la nube corporativa garantiza que los datos estén cifrados, controlados y con copias de seguridad adecuadas.

### 5.-El Peligro de los Pendrives y Dispositivos USB

**Visual:** Gráfico de un virus entrando desde un USB e icono de candado para el cifrado.

**Locución:** Los dispositivos USB son una de las principales vías de entrada de malware. No utilices nunca pendrives que no hayan sido suministrados por FoodLogistic. Además, si por motivos excepcionales debes transportar datos en un USB, este debe estar obligatoriamente cifrado.

### 6.-Tratamiento Físico y Destrucción de Documentos

**Visual:** Imagen de una trituradora de papel en funcionamiento.

**Locución:** Cuando un documento en papel ya no es necesario, nunca lo tires a la papelera convencional si contiene datos personales. La ley exige una destrucción segura; utiliza siempre la trituradora de la oficina. Una mala gestión puede comportar sanciones gravísimas para FoodLogistic.

## Guión video 2: Protección de datos en RRHH y gestión (Específico)

**Público:** Personal de administración y Recursos Humanos.

### 1.-Introducción a la Gestión de RRHH

**Visual:** Título del vídeo y mención a los datos de "categorías especiales".

**Locución:** El personal de administración y RRHH gestiona datos de alto riesgo, como nóminas o datos de salud (categorías especiales), que requieren una protección superior. Debemos liderar el cumplimiento de la LOPDGDD y el RGPD.

### 2.-Gestión Legal del Currículum Vitae (CV)

**Visual:** Flujo de vida de un CV: recepción, información, uso y destrucción.

**Locución:** El CV contiene gran cantidad de datos personales. Al recibir uno, debemos informar al candidato sobre quién tratará sus datos y con qué finalidad. El consentimiento debe ser una acción afirmativa clara. Si no hay interés legítimo en conservarlo tras el proceso, debe ser destruido de forma segura.

### 3.-Responsable vs. Encargado del Tratamiento

**Visual:** Organigrama con FoodLogistic como "Responsable" y la gestoría externa como "Encargado".

**Locución:** FoodLogistic es el Responsable del Tratamiento, decide el porqué y cómo se usan los datos. La gestoría, al hacer las nóminas, actúa como Encargado del Tratamiento bajo nuestras instrucciones. Esta relación debe estar regulada por contrato escrito.

### 4.-Deber de Confidencialidad (Artículo 5 RGPD)

**Visual:** Imagen de un contrato de confidencialidad y texto del Artículo 5 del RGPD.

**Locución:** El Artículo 5 establece los principios de seguridad y confidencialidad. Todo el personal de RRHH debe firmar compromisos de confidencialidad. Este deber de secreto es indefinido, incluso tras finalizar la relación laboral. Nunca se deben comentar datos de empleados con terceros o compañeros no autorizados.

### 5.-Gestión de los Derechos del Interesado (Derechos ARSULIPO)

**Visual:** Lista de derechos: Acceso, Rectificación, Supresión, Limitación, Portabilidad y Oposición.

**Locución:** Empleados y clientes pueden ejercer sus derechos en cualquier momento. Si recibís una solicitud, debéis tramitarla con la máxima celeridad para cumplir los plazos legales.

### 6.-Notificación de Brechas de Seguridad

**Visual:** Icono de alerta y el número "72 horas".

**Locución:** Si detectamos pérdida de datos, robo de un ordenador o un ataque informático, estamos ante una violación de seguridad. FoodLogistic debe notificarlo a la AEPD en un plazo máximo de 72 horas. La comunicación interna inmediata es vital para evitar sanciones que pueden llegar a los 10 millones de euros.

---

# Tasca 2: Producció de Vídeos

Heu de produir dos vídeos.

## Vídeo 1: "Compliment legal en el dia a dia a FoodLogistic" (General)

[Vídeo 1: "Compliment legal en el dia a dia a FoodLogistic" Jhon Justiniano-Hugo Muiños](https://drive.google.com/file/d/18qJoyxsGizD_UAS4EyVxIQVMArDoamDv/view?usp=sharing)

## Vídeo 2: "Protecció de dades a RRHH i Gestió" (Específic)

[Vídeo 2: "Protecció de dades a RRHH i Gestió" Jhon Justiniano-Hugo Muiños](https://drive.google.com/file/d/1vpvtlvHqkmaUfRsqBQ0Mc8G60LrNWCep/view?usp=sharing)

---
# Funetes consultadas

[RA5: LEGISLACIÓ SEGURETAT I PROTECCIÓ DE DADES](https://smx2n.github.io/0226-RA5/)

[Agencia Española de Protecció de Datos](https://www.aepd.es/)

---

# IA utilizadas

[Google NotebookLM](https://access.workspace.google.com/ServiceNotAllowed?application=692380834322&source=scrip&continue=https://notebooklm.google.com/) para hacer el guión.

[Gamma](https://gamma.app/es) para hacer las presentaciones.

---

## Tienen la actividad: [T05: Vídeo formatiu LOPD empleats: Jhon Justiniano-Hugo Muiños](https://docs.google.com/document/d/1RBB-XFElGaGn-cxyffKcd174mfz74nFWx_xEnFWaw7w/edit?usp=sharing) por si se les hes más comodo.

---

[Torna a l'enunciat](README.md)

